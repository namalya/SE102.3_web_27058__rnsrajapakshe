
<?php
// Create variables x and y and assign values
$x = 6;
$y = 4;

// Perform calculations
$sum = $x + $y;
$difference = $x - $y;
$product = $x * $y;
$division = $x / $y;

// Display the results in the specified format
echo "Sum: " . $sum . "<br>";
echo "Difference: " . $difference . "<br>";
echo "Product: " . $product . "<br>";
echo "Division: " . $division . "<br>";
?>



